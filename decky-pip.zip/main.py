# Decky Loader compatibility stub
# This plugin is frontend-only (no backend logic)

class Plugin:
    async def _main(self):
        pass
